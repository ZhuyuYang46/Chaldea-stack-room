export default function Home() {
  return (
    <div className="pt-[100px] min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <h1 className="text-2xl font-semibold">Welcome to Chaldea</h1>
    </div>
  );
}
