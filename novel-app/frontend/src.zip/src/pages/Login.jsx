import React, { useState, useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import { login, fetchProtected } from '../api/auth'
import { AuthContext } from '../context/AuthContext.jsx'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errorMsg, setErrorMsg] = useState('')
  const nav = useNavigate()

  const { setUser } = useContext(AuthContext)

  const handleSubmit = async e => {
    e.preventDefault()
    setErrorMsg('')
    try {
      const { data: loginRes } = await login({ email, password })
      localStorage.setItem('token', loginRes.token)

      const { data: protectedRes } = await fetchProtected()
      setUser(protectedRes.user)

      nav('/novels')
    } catch (err) {
      console.error(err)
      const msg = err.response?.data?.message || 'Login failed. Please check your credentials.'
      setErrorMsg(msg)
    }
  }

  return (
    <div className="container">
      <h1>Login</h1>

      {errorMsg && <p className="error-msg">{errorMsg}</p>}

      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
          className="input-field"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          required
          className="input-field"
        />
        <button type="submit" className="btn-primary">
          Sign in
        </button>
      </form>
    </div>
  )
}
